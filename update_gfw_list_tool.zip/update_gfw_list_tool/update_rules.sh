#generate new dnsmasq_gfwlist.conf
conf="dnsmasq_list.conf"
my_rule_file="my_domains.txt"
./gfwlist2dnsmasq.sh -d 208.67.222.222 -p 443 -s gfwlist --extra-domain-file $my_rule_file -o $conf

# copy file
cp -f ./$conf /etc/dnsmasq.d/dnsmasq_list.conf

#restart all service
/etc/init.d/dnsmasq restart
/etc/init.d/firewall restart
/etc/init.d/myshadowsocks start
/etc/init.d/myshadowsocks enable

echo "update finshed!"
